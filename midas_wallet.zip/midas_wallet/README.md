# midas_wallet

A new Flutter project.
