package com.example.midas_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
